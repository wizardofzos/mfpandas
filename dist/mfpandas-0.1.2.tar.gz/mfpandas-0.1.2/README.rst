mfpandas
########

The framework for working with various Mainframe (z/OS) datastructures via Pandas Dataframes.
Read the docs at https:/mfpandas.readthedocs.io 

Installation::

    pip install mfpandas 


This used to be `pyracf` but that name is now being used by an awesome framework to work with RACF directly from python.
Read more about it via: https://github.com/ambitus/pyracf 
