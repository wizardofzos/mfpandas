mfpandas
########

This is still being worked on. Once 'ready' it will replace https://pypi.org/project/pyracf/ 

Minimalistic todo list:

  - document all (current) IRRDBU00 Things (done)
  - finalize DCOLLECT
  - describe 'collaboration' in docs
  - extend cookbooks


This version is on 'pypi' as https://pypi.org/project/mfpandas/ but might not be ready enough yet :)
